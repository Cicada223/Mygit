package ch11;

public interface Vehicle {
	public void speedUp();
	public void speedDown();
	public void handle();
}
